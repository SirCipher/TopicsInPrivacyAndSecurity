The tool requires three command line argument: training file location, test file location, outlier coefficient

For example:
java -jar tool.jar training_log test_log 5